Hello you,

First of all thank you for downloading this file.
All buttons are highly customizeable in both text, color and style.

The PSD-file is ordered in grouped categories similar to the groups in the preview. 
Under these categories they are ordered in color - which should be quite straightforward.

The Font ALLER can be downloaded for free at: http://www.fontsquirrel.com/fonts/Aller
(or any similar site found by a quick search on Google)

If you need any support I, the author, can be contacted on: m.ejsing@gmail.com


Thanks,
Mads Ejsing - www.ejsing.deviantart.com